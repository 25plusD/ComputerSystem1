#include<stdio.h>
void printid(){
	printf("U202215510\n");
}
void *myprint = printid;
